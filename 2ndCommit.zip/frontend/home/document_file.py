import os 


log_path = os.getcwd()
client_id = '1ZFEE6GY5Z-100'
secret_key = 'WI9JMHCADW'
redirect_url = 'http://127.0.0.1:5000/login'
username = 'XV18626'
password ='Vishv@15'
pin1 = '9'
pin2 = '1'
pin3 = '4'
pin4 = '4'
response_type = 'code'
grant_type = 'authorization_code'